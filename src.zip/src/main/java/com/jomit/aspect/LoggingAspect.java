package com.jomit.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAspect {

	@Before("execution(public String index(ModelMap model))")
	public void loggingAdvice() {
		System.out.println("Advice run. Get Method Called");
	}
}
