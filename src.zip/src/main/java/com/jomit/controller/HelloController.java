package com.jomit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/hello")
public class HelloController {

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String index(ModelMap model) {
		model.addAttribute("message","Hello Spring WEB MVC!");
		System.out.println("hello");
		return "hello";
	}
	
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public @ResponseBody String profile(
	            @RequestParam("firstname") String firstname,
	            @RequestParam("lastname") String lastname) {
	        System.out.println(firstname);
	        System.out.println(lastname);
	        // Process the request
	        // Prepare the response string
	        String response = String.format("me llamo %s %s",firstname,lastname);
	        return response;
	}
}
